import { StageDef } from './types';

export const stage1: StageDef = {
  id: "stage-1",
  stageNumber: 1,
  title: "أساسيات الحاسوب وحل المشكلات",
  units: [
    {
      id: "unit-1",
      stageId: "stage-1",
      unitNumber: 1,
      title: "كيف يعالج الحاسوب المعلومات",
      description: "فهم النظام الثنائي، البايت، وكيفية تمثيل البيانات داخل المعالج.",
      content: [
        { type: "h1", content: "الوحدة 1: كيف يعالج الحاسوب المعلومات" },
        { type: "p", content: "الحاسوب في جوهره لا يفهم النصوص أو الصور أو الألوان. هو يفهم شيئاً واحداً فقط: التيار الكهربائي إما موجود (1) أو غير موجود (0). من هنا تبدأ رحلتنا لفهم كيف يُبنى كل شيء من هذين الرقمين." },
        
        { type: "h2", content: "1. النظام الثنائي (Binary System)" },
        { type: "p", content: "نحن البشر نستخدم النظام العشري (الأساس 10) لأن لدينا 10 أصابع. يتكون من الأرقام من 0 إلى 9. لكن الحاسوب يستخدم النظام الثنائي (الأساس 2) ويتكون من 0 و 1 فقط." },
        { type: "callout", calloutType: "note", content: [
          { type: "p", content: "كل نبضة كهربائية أو رقم (0 أو 1) يسمى بت (Bit)، وهو أصغر وحدة معلومات." }
        ]},
        { type: "p", content: "كيف نعد بالثنائي؟" },
        { type: "table", headers: ["العشري", "الثنائي", "كيف نقرأه؟"], rows: [
          ["0", "0000", "صفر"],
          ["1", "0001", "واحد"],
          ["2", "0010", "اثنان (انتهت أرقام الخانة الأولى فننتقل للتي تليها)"],
          ["3", "0011", "ثلاثة"],
          ["4", "0100", "أربعة"]
        ]},

        { type: "h2", content: "2. البايت وأحجام البيانات" },
        { type: "p", content: "لأن البت صغير جداً، تم تجميع كل 8 بتات في وحدة تسمى بايت (Byte). بايت واحد يمكن أن يمثل 256 قيمة مختلفة (من 00000000 إلى 11111111)." },
        { type: "table", headers: ["الوحدة", "الحجم", "مثال للحجم"], rows: [
          ["1 Byte", "8 Bits", "حرف واحد (مثل حرف 'A')"],
          ["1 Kilobyte (KB)", "1024 Bytes", "رسالة نصية قصيرة"],
          ["1 Megabyte (MB)", "1024 KB", "صورة عالية الجودة أو كتاب نصي"],
          ["1 Gigabyte (GB)", "1024 MB", "فيلم بجودة عادية أو لعبة بسيطة"],
          ["1 Terabyte (TB)", "1024 GB", "مكتبة ضخمة من الفيديوهات والألعاب"]
        ]},

        { type: "h2", content: "3. تمثيل النصوص (ASCII & Unicode)" },
        { type: "p", content: "كيف يخزن الحاسوب حرف 'A'؟ عن طريق جدول تحويل. تاريخياً كان يستخدم جدول ASCII الذي يعطي كل حرف باللغة الإنجليزية رقماً، فحرف 'A' هو الرقم 65، والذي يحول إلى ثنائي (01000001)." },
        { type: "p", content: "مع انتشار الحواسيب عالمياً، ظهرت الحاجة لتمثيل لغات أخرى كالعربية. فظهر معيار Unicode وطريقة ترميز UTF-8 التي تدعم كل لغات العالم وحتى الإيموجي." },
        
        { type: "h2", content: "4. مسار البيانات داخل الحاسوب" },
        { type: "ascii", content: `
  [Input] ──▶ [CPU] ──▶ [Output]
               ▲ │
               │ ▼
             [RAM]
               ▲ │
               │ ▼
           [Storage]
` },
        { type: "ul", items: [
          [{ type: "p", content: "القرص الصلب (Storage): تخزين دائم وكبير ولكنه بطيء." }],
          [{ type: "p", content: "الذاكرة العشوائية (RAM): تخزين مؤقت وسريع جداً، تنقل البيانات للمعالج." }],
          [{ type: "p", content: "المعالج (CPU): عقل الحاسوب، يقوم بالعمليات الحسابية والمنطقية." }]
        ]},

        { type: "h2", content: "5. لغات البرمجة (المترجمات والمفسرات)" },
        { type: "p", content: "نحن لا نكتب الكود بالـ 0 و 1 بل بلغات قريبة من الإنجليزية (مثل Python و Java). نحتاج إلى برامج تحول هذا الكود إلى لغة الآلة. هناك نوعان رئيسيان:" },
        { type: "ul", items: [
          [{ type: "p", content: "المترجم (Compiler): يحول الكود كاملاً إلى ملف تنفيذي قبل تشغيله (مثل Java و C++)." }],
          [{ type: "p", content: "المفسر (Interpreter): يقرأ الكود وينفذه سطراً بسطر في نفس اللحظة (مثل Python و JavaScript)." }]
        ]},

        { type: "active-recall", questions: [
          { q: "ما هو الـ Bit؟", a: "أصغر وحدة بيانات في الحاسوب، وقيمته إما 0 أو 1." },
          { q: "كم Bit يوجد في الـ Byte الواحد؟", a: "8 Bits." },
          { q: "ما الفرق بين RAM و Storage؟", a: "الـ RAM سريعة جداً وتمحى بمجرد إطفاء الجهاز، أما Storage فهي بطيئة وتحتفظ بالبيانات بشكل دائم." },
          { q: "ما الفرق بين Compiler و Interpreter؟", a: "المترجم يحول البرنامج كاملاً دفعة واحدة، بينما المفسر ينفذ البرنامج سطراً بسطر." }
        ]}
      ]
    },
    {
      id: "unit-2",
      stageId: "stage-1",
      unitNumber: 2,
      title: "تحليل المشكلات وسير العمليات",
      description: "التفكير الخوارزمي، الشيفرة الزائفة (Pseudocode) والمخططات الانسيابية.",
      content: [
        { type: "h1", content: "الوحدة 2: تحليل المشكلات وسير العمليات" },
        { type: "h2", content: "1. ما هي المشكلة البرمجية؟" },
        { type: "p", content: "أي برنامج هو ببساطة نظام يتلقى مدخلات (Inputs)، يقوم بمعالجتها (Process)، ثم يخرج نتيجة (Outputs) في ظل قيود معينة (Constraints)." },
        
        { type: "h2", content: "2. التفكير الخوارزمي" },
        { type: "p", content: "الخوارزمية هي سلسلة من الخطوات المنطقية الواضحة والمحددة لحل مشكلة ما. قبل كتابة أي كود، يجب أن نكتب الخوارزمية بلغة البشر، وهو ما يسمى بالـ Pseudocode (الشيفرة الزائفة)." },
        
        { type: "code", language: "text", title: "Pseudocode: حساب خصم", content: `START
  INPUT price
  IF price > 100 THEN
    discount = price * 0.10
  ELSE
    discount = 0
  END IF
  final_price = price - discount
  OUTPUT final_price
END` },

        { type: "h2", content: "3. المخططات الانسيابية (Flowcharts)" },
        { type: "p", content: "هي تمثيل بصري للخوارزمية باستخدام أشكال هندسية متفق عليها عالمياً." },
        { type: "ascii", content: `
  ( Start / End )  -> أشكال بيضاوية
  [ Process ]      -> مستطيل (للحسابات)
  / Input-Output / -> متوازي أضلاع
  < Decision >     -> معين (للأسئلة المنطقية نعم/لا)
` },

        { type: "project", title: "تحليل نظام صراف آلي (ATM)", content: [
          { type: "p", content: "دعنا نحلل خوارزمية سحب نقود:" },
          { type: "code", language: "text", content: `START
  INPUT pin_code
  IF pin_code IS correct THEN
    INPUT amount_to_withdraw
    IF balance >= amount_to_withdraw THEN
      balance = balance - amount_to_withdraw
      DISPENSE cash
      OUTPUT "Success"
    ELSE
      OUTPUT "Insufficient Funds"
    END IF
  ELSE
    OUTPUT "Wrong PIN"
  END IF
END` }
        ]},

        { type: "active-recall", questions: [
          { q: "ما هي المدخلات (Inputs)؟", a: "البيانات التي يستقبلها البرنامج للعمل عليها." },
          { q: "ما هو الـ Pseudocode؟", a: "طريقة لكتابة خطوات الخوارزمية بلغة البشر قبل تحويلها إلى كود برمجي." },
          { q: "ما هو الشكل الهندسي المستخدم لاتخاذ قرار (if) في المخطط الانسيابي؟", a: "المعين (Diamond)." }
        ]}
      ]
    },
    {
      id: "unit-3",
      stageId: "stage-1",
      unitNumber: 3,
      title: "أنواع البيانات والمتغيرات (Python)",
      description: "الأرقام، النصوص، المتغيرات، والعمليات الأساسية باستخدام بايثون.",
      content: [
        { type: "h1", content: "الوحدة 3: المتغيرات وأنواع البيانات" },
        { type: "p", content: "سنبدأ بكتابة كود حقيقي باستخدام لغة Python، وهي لغة صديقة للمبتدئين ومستخدمة بكثرة في الذكاء الاصطناعي وهندسة البيانات." },

        { type: "h2", content: "1. ما هو المتغير؟" },
        { type: "p", content: "تخيل المتغير كصندوق في ذاكرة الحاسوب (RAM) تضع عليه اسماً، وتخزن داخله قيمة لتستخدمها لاحقاً." },
        { type: "code", language: "python", content: `user_name = "Ahmed"
age = 25
print(user_name) # سيطبع Ahmed` },

        { type: "callout", calloutType: "best-practice", content: [
          { type: "p", content: "في بايثون نستخدم صيغة ثعبانية (snake_case) لتسمية المتغيرات. الكلمات بحروف صغيرة مفصولة بشرطة سفلية: student_first_name." }
        ]},

        { type: "h2", content: "2. أنواع البيانات (Data Types)" },
        { type: "ul", items: [
          [{ type: "p", content: "int: أرقام صحيحة (10, -5)" }],
          [{ type: "p", content: "float: أرقام عشرية (3.14, 0.5)" }],
          [{ type: "p", content: "str (String): نصوص ('Hello')" }],
          [{ type: "p", content: "bool (Boolean): قيم منطقية (True, False)" }]
        ]},

        { type: "h2", content: "3. العمليات الحسابية" },
        { type: "code", language: "python", content: `x = 10
y = 3
print(x + y)   # 13 (جمع)
print(x / y)   # 3.333... (قسمة عادية، الناتج دائماً float)
print(x // y)  # 3 (قسمة صحيحة، تحذف الكسور)
print(x % y)   # 1 (باقي القسمة Modulo)
print(x ** y)  # 1000 (الأس 10 تكعيب)` },

        { type: "callout", calloutType: "mistake", content: [
          { type: "p", content: "لا تخلط بين علامة '=' الواحدة (وهي للتخصيص: وضع قيمة في متغير) وعلامة '==' (وهي للمقارنة والسؤال: هل x يساوي y؟)." }
        ]},

        { type: "h2", content: "4. النصوص (Strings)" },
        { type: "p", content: "النص هو سلسلة من الأحرف. يمكننا دمج النصوص وتعديلها بسهولة." },
        { type: "code", language: "python", content: `name = "Sara"
score = 95
# الطريقة الحديثة والمفضلة (f-strings)
message = f"الطالبة {name} حصلت على درجة {score}"
print(message.upper()) # يحول الحروف لكبيرة` },

        { type: "active-recall", questions: [
          { q: "ما نوع البيانات للقيمة 3.14؟", a: "float (رقم عشري)." },
          { q: "ما نتيجة العملية 10 % 3 ؟", a: "النتيجة 1 (باقي قسمة 10 على 3)." },
          { q: "ما الفائدة من f-strings؟", a: "تسمح بدمج المتغيرات داخل النص بسهولة وبطريقة مقروءة." }
        ]}
      ]
    },
    {
      id: "unit-4",
      stageId: "stage-1",
      unitNumber: 4,
      title: "التحكم في التدفق والمنطق",
      description: "الشروط (if/else) والحلقات التكرارية (Loops).",
      content: [
        { type: "h1", content: "الوحدة 4: التحكم في التدفق والمنطق" },
        
        { type: "h2", content: "1. الشروط (if / elif / else)" },
        { type: "p", content: "كيف نجعل البرنامج يتخذ قرارات بناءً على البيانات؟ باستخدام if." },
        { type: "code", language: "python", content: `grade = 85

if grade >= 90:
    print("ممتاز")
elif grade >= 80:
    print("جيد جداً")
else:
    print("يحتاج لتحسين")` },
        { type: "callout", calloutType: "note", content: [
          { type: "p", content: "لاحظ المسافة البادئة (Indentation) قبل دالة print. بايثون تعتمد على المسافات لتحديد ما يوجد داخل الشرط، وليس على الأقواس {} كاللغات الأخرى." }
        ]},

        { type: "h2", content: "2. المعاملات المنطقية (Logical Operators)" },
        { type: "p", content: "للربط بين عدة شروط نستخدم and, or, not." },
        { type: "code", language: "python", content: `is_weekend = True
has_homework = False

if is_weekend and not has_homework:
    print("يمكنك اللعب!")
else:
    print("عليك إنجاز المهام.")` },

        { type: "h2", content: "3. حلقة for" },
        { type: "p", content: "تستخدم لتكرار كود عدد محدد من المرات." },
        { type: "code", language: "python", content: `# ستطبع الأرقام من 0 إلى 4
for i in range(5):
    print(i)` },

        { type: "h2", content: "4. حلقة while" },
        { type: "p", content: "تستمر في التكرار طالما أن الشرط صحيح (True)." },
        { type: "code", language: "python", content: `counter = 5
while counter > 0:
    print(counter)
    counter -= 1  # هذا يمنع الدوران اللانهائي (Infinite Loop)
print("انطلاق!")` },

        { type: "project", title: "لعبة تخمين الرقم", content: [
          { type: "code", language: "python", content: `import random

secret_number = random.randint(1, 10)
guess = 0

print("خمّن الرقم من 1 إلى 10")

while guess != secret_number:
    # input تأخذ نصاً، لذا نحوله إلى رقم (int)
    guess = int(input("محاولتك: "))
    
    if guess > secret_number:
        print("رقمك أكبر من المطلوب")
    elif guess < secret_number:
        print("رقمك أصغر من المطلوب")

print("مبروك! الإجابة صحيحة.")` }
        ]},

        { type: "active-recall", questions: [
          { q: "متى نستخدم if مقابل elif؟", a: "if للشرط الأول، و elif (أي else if) للفحص في حال فشل الشرط الذي سبقه." },
          { q: "ماذا تفعل دالة range(3) في حلقة for؟", a: "تولد الأرقام 0, 1, 2." },
          { q: "كيف نمنع حلقة while من العمل للأبد (Infinite Loop)؟", a: "يجب تحديث المتغير الذي يتم فحصه في الشرط (مثل counter -= 1) بحيث يصبح الشرط False في النهاية." }
        ]}
      ]
    },
    {
      id: "unit-5",
      stageId: "stage-1",
      unitNumber: 5,
      title: "الدوال والنمطية",
      description: "تنظيم الكود وإعادة استخدامه عبر الدوال (Functions).",
      content: [
        { type: "h1", content: "الوحدة 5: الدوال والنمطية" },
        { type: "p", content: "كلما كبر البرنامج، أصبح الكود معقداً. الدوال تسمح لك بتغليف جزء من الكود، إعطائه اسماً، واستدعائه متى شئت. هذا يطبق مبدأ DRY (Don't Repeat Yourself)." },

        { type: "h2", content: "1. تعريف واستدعاء الدالة" },
        { type: "code", language: "python", content: `def greet(name):    # name يسمى Parameter (وسيط)
    print(f"مرحباً {name}!")

greet("أحمد")       # "أحمد" تسمى Argument (معطى)` },

        { type: "h2", content: "2. الإرجاع (Return) مقابل الطباعة" },
        { type: "callout", calloutType: "warning", content: [
          { type: "p", content: "طباعة النتيجة (print) تفيد المبرمج فقط ليراها في الشاشة. أما إرجاع النتيجة (return) فتفيد البرنامج ليأخذ النتيجة ويستخدمها في حسابات أخرى." }
        ]},
        { type: "code", language: "python", content: `def add(a, b):
    return a + b

# النتيجة محفوظة في متغير، ويمكننا إكمال الحساب
result = add(5, 3)
final_result = add(result, 10)
print(final_result) # 18` },

        { type: "h2", content: "3. نطاق المتغيرات (Scope)" },
        { type: "p", content: "المتغيرات المعرفة داخل دالة لا يمكن رؤيتها من الخارج." },
        { type: "code", language: "python", content: `def my_func():
    secret = "مخفي"
    
my_func()
# print(secret)  # سيؤدي هذا لخطأ: NameError` },

        { type: "h2", content: "4. التلميحات والتوثيق (Type Hints & Docstrings)" },
        { type: "p", content: "من أفضل ممارسات كتابة كود احترافي." },
        { type: "code", language: "python", content: `def calculate_average(grades: list[float]) -> float:
    """
    تقوم هذه الدالة بحساب المتوسط الحسابي لقائمة درجات.
    """
    if not grades:
        return 0.0
    return sum(grades) / len(grades)` },

        { type: "active-recall", questions: [
          { q: "ما الفرق بين Parameter و Argument؟", a: "الـ Parameter هو المتغير في تعريف الدالة. الـ Argument هو القيمة الفعلية الممررة عند استدعاء الدالة." },
          { q: "ماذا يحدث للكود الموجود بعد جملة return في نفس الدالة؟", a: "لا يتم تنفيذه. جملة return تنهي عمل الدالة فوراً." },
          { q: "ما هي الـ Docstring؟", a: "تعليق نصي يوضع في بداية الدالة لشرح وظيفتها للمبرمجين الآخرين." }
        ]}
      ]
    },
    {
      id: "unit-6",
      stageId: "stage-1",
      unitNumber: 6,
      title: "التعامل مع مجموعات البيانات",
      description: "القوائم (Lists) والقواميس (Dictionaries) في Python.",
      content: [
        { type: "h1", content: "الوحدة 6: مجموعات البيانات" },
        { type: "p", content: "غالباً لا نتعامل مع رقم واحد أو نص واحد، بل مع بيانات كثيرة (قائمة طلاب، درجات، إعدادات مستخدم). نحتاج هياكل لتخزين هذه البيانات." },

        { type: "h2", content: "1. القوائم (Lists)" },
        { type: "p", content: "القائمة تخزن عناصر مرتبة ويمكن تغييرها." },
        { type: "code", language: "python", content: `fruits = ["تفاح", "موز", "برتقال"]

print(fruits[0])      # تفاح (الترقيم يبدأ من 0)
print(fruits[-1])     # برتقال (الرقم السالب يبدأ من النهاية)

fruits.append("عنب")  # إضافة للآخر
fruits.remove("موز")  # حذف بالقيمة
print(len(fruits))    # معرفة عدد العناصر` },

        { type: "h2", content: "2. القواميس (Dictionaries)" },
        { type: "p", content: "تخزن البيانات كأزواج من (مفتاح وقيمة) أو Key-Value Pairs. وهي سريعة جداً في البحث." },
        { type: "code", language: "python", content: `student = {
    "name": "سالم",
    "age": 20,
    "major": "علوم حاسب"
}

# جلب قيمة
print(student["name"])

# التعديل والإضافة
student["age"] = 21
student["gpa"] = 4.5

# الدوران على القاموس
for key, value in student.items():
    print(f"{key}: {value}")` },

        { type: "callout", calloutType: "ai-tip", content: [
          { type: "p", content: "خلف الكواليس، Dictionary في بايثون يعمل باستخدام بنية تسمى Hash Map، وهذا ما يجعله سريعاً جداً O(1) عند البحث عن المفاتيح، مقارنة بالقوائم List التي تستغرق وقتاً أطول O(n) في البحث المباشر عن عنصر." }
        ]},

        { type: "project", title: "نظام إدارة درجات متقدم", content: [
          { type: "code", language: "python", content: `students_data = [
    {"name": "Ali", "grades": [85, 90, 92]},
    {"name": "Sara", "grades": [95, 98, 96]}
]

for s in students_data:
    avg = sum(s["grades"]) / len(s["grades"])
    print(f"{s['name']}: {avg:.1f}")` }
        ]},

        { type: "active-recall", questions: [
          { q: "بأي رقم يبدأ الترقيم (Indexing) في القوائم؟", a: "يبدأ بالرقم صفر (0)." },
          { q: "متى نستخدم List ومتى نستخدم Dictionary؟", a: "استخدم List لمجموعة عناصر مرتبة متشابهة. استخدم Dictionary عندما تحتاج لربط معلومة بأخرى (اسم وقيمة) وتسهيل البحث عنها." },
          { q: "كيف نضيف عنصراً جديداً لقائمة List؟", a: "باستخدام دالة append()." }
        ]}
      ]
    }
  ]
};
