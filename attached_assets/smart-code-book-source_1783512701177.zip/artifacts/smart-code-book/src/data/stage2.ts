import { StageDef } from './types';

export const stage2: StageDef = {
  id: "stage-2",
  stageNumber: 2,
  title: "مفاهيم متقدمة في البرمجة",
  units: [
    {
      id: "unit-7",
      stageId: "stage-2",
      unitNumber: 7,
      title: "الخوارزميات والتعقيد (Java)",
      description: "تحليل كفاءة الكود: Big O، خوارزميات الترتيب والبحث، وهياكل البيانات الأساسية.",
      content: [
        { type: "h1", content: "الوحدة 7: الخوارزميات والتعقيد الزمني (Big O)" },
        { type: "p", content: "ننتقل الآن إلى Java — لغة قوية وصارمة تُعلّمك ثقافة الكتابة الاحترافية. في هذه الوحدة سنتعلم معياراً أساسياً يسأل عنه كل محاور: كيف نقيس كفاءة الكود؟" },

        { type: "h2", content: "1. ما هو Big O Notation؟" },
        { type: "p", content: "Big O يصف كيف ينمو وقت تنفيذ الكود (أو حجم الذاكرة التي يستهلكها) مع زيادة حجم المدخلات (n). نحن نهتم بالحالة الأسوأ دائماً." },
        { type: "table", headers: ["التعقيد", "الاسم", "مثال عملي", "n=1,000 عملية تقريبية"], rows: [
          ["O(1)", "ثابت", "وصول لعنصر مصفوفة بالـ Index", "1"],
          ["O(log n)", "لوغاريتمي", "Binary Search في قائمة مرتبة", "10"],
          ["O(n)", "خطي", "البحث في قائمة غير مرتبة", "1,000"],
          ["O(n log n)", "شبه خطي", "Merge Sort, Quick Sort", "10,000"],
          ["O(n²)", "تربيعي", "Bubble Sort, حلقة داخل حلقة", "1,000,000"],
          ["O(2ⁿ)", "أسي", "Fibonacci Naive", "~10³⁰"]
        ]},

        { type: "callout", calloutType: "note", title: "قاعدة أساسية", content: [
          { type: "p", content: "عند حساب Big O، نتجاهل الثوابت والمصطلحات الأقل سيطرة: O(2n + 5) = O(n), و O(n² + n) = O(n²). نهتم بالنمو العام فقط." }
        ]},

        { type: "h2", content: "2. البحث الخطي (Linear Search) — O(n)" },
        { type: "p", content: "أبسط خوارزمية بحث. نمر على كل عنصر حتى نجد ما نريد. لا تشترط ترتيب المصفوفة." },
        { type: "code", language: "java", title: "LinearSearch.java", content: `public class Search {
    /**
     * O(n) time complexity — يفحص كل عنصر في أسوأ الحالات
     */
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) return i;  // وجدناه
        }
        return -1;  // لم نجده
    }

    /**
     * O(log n) — يشترط مصفوفة مرتبة، يقسم المصفوفة لنصفين
     */
    public static int binarySearch(int[] sortedArr, int target) {
        int left = 0, right = sortedArr.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;  // تجنب Integer Overflow

            if (sortedArr[mid] == target)   return mid;
            else if (sortedArr[mid] < target) left = mid + 1;  // الهدف في النصف الأيمن
            else                              right = mid - 1;  // الهدف في النصف الأيسر
        }
        return -1;
    }
}` },

        { type: "h2", content: "3. خوارزميات الترتيب" },
        { type: "h3", content: "Bubble Sort — O(n²) — التعلمي فقط" },
        { type: "p", content: "تقارن كل عنصرين متجاورين وتبادلهما إن كانا في ترتيب خاطئ. تكرر حتى لا يبقى تبادل." },
        { type: "code", language: "java", title: "BubbleSort.java", content: `public static void bubbleSort(int[] arr) {
    int n = arr.length;
    for (int i = 0; i < n - 1; i++) {
        boolean swapped = false;  // تحسين: توقف مبكر إن كانت مرتبة
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                // التبادل
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                swapped = true;
            }
        }
        if (!swapped) break;  // المصفوفة مرتبة بالفعل
    }
}` },

        { type: "h3", content: "Merge Sort — O(n log n) — احترافي" },
        { type: "p", content: "قسم المصفوفة لنصفين، رتب كل نصف (بنفس الطريقة عودياً)، ثم ادمج النصفين المرتبين. هذا تطبيق لمبدأ 'فرّق تسد' (Divide and Conquer)." },
        { type: "code", language: "java", title: "MergeSort.java", content: `public static void mergeSort(int[] arr, int left, int right) {
    if (left >= right) return;  // حالة القاعدة: مصفوفة بعنصر واحد

    int mid = (left + right) / 2;
    mergeSort(arr, left, mid);    // رتّب النصف الأيسر
    mergeSort(arr, mid + 1, right); // رتّب النصف الأيمن
    merge(arr, left, mid, right); // ادمجهما
}

private static void merge(int[] arr, int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    // مصفوفتان مؤقتتان
    int[] L = new int[n1], R = new int[n2];
    System.arraycopy(arr, left, L, 0, n1);
    System.arraycopy(arr, mid + 1, R, 0, n2);

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) arr[k++] = L[i++];
        else               arr[k++] = R[j++];
    }
    // نسخ ما تبقى
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];
}` },

        { type: "h2", content: "4. هياكل البيانات الأساسية" },
        { type: "table", headers: ["الهيكل", "Java", "إضافة O", "البحث O", "الوصول O", "متى تستخدمه؟"], rows: [
          ["Dynamic Array", "ArrayList", "O(1) مستهلكة", "O(n)", "O(1)", "عندما تحتاج وصولاً بالـ Index"],
          ["Linked List", "LinkedList", "O(1) من الطرفين", "O(n)", "O(n)", "عندما تُضيف وتحذف كثيراً"],
          ["Hash Map", "HashMap", "O(1)", "O(1)", "N/A", "ربط مفتاح بقيمة، بحث فوري"],
          ["Stack", "Stack/Deque", "O(1)", "O(n)", "O(1) (القمة)", "LIFO: Undo، استدعاء الدوال"],
          ["Queue", "LinkedList/Queue", "O(1)", "O(n)", "O(1) (الأول)", "FIFO: طوابير الانتظار"],
          ["Tree Set", "TreeSet", "O(log n)", "O(log n)", "N/A", "بيانات مرتبة بلا تكرار"]
        ]},

        { type: "code", language: "java", title: "HashMap في العمل الحقيقي", content: `import java.util.*;

public class WordFrequency {
    // حساب تكرار كل كلمة في نص — O(n) وقتاً ومكاناً
    public static Map<String, Integer> countWords(String text) {
        Map<String, Integer> freq = new HashMap<>();
        String[] words = text.toLowerCase().split("\\s+");

        for (String word : words) {
            // merge: إذا الكلمة موجودة، أضف 1، وإلا ابدأ بـ 1
            freq.merge(word, 1, Integer::sum);
        }
        return freq;
    }

    // أكثر 5 كلمات تكراراً
    public static List<Map.Entry<String, Integer>> topWords(Map<String, Integer> freq) {
        return freq.entrySet().stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
            .limit(5)
            .toList();
    }
}` },

        { type: "h2", content: "5. مسائل LeetCode الكلاسيكية" },
        { type: "p", content: "دراسة هذه المسائل الثلاث تعطيك أساساً قوياً لمقابلات Google وMeta وAmazon:" },

        { type: "code", language: "java", title: "المسألة 1: Two Sum — O(n) باستخدام HashMap", content: `/**
 * المشكلة: أوجد عنصرين في المصفوفة مجموعهما يساوي target.
 * المدخل: int[] nums = {2, 7, 11, 15}, target = 9
 * المخرج: [0, 1] (لأن nums[0] + nums[1] = 9)
 * التعقيد: O(n) وقتاً، O(n) مكاناً
 */
public int[] twoSum(int[] nums, int target) {
    Map<Integer, Integer> seen = new HashMap<>();  // {قيمة: index}

    for (int i = 0; i < nums.length; i++) {
        int complement = target - nums[i];  // ماذا نحتاج بالإضافة لهذا الرقم؟

        if (seen.containsKey(complement)) {
            return new int[]{seen.get(complement), i};  // وجدنا الزوج!
        }
        seen.put(nums[i], i);  // سجّل هذا العنصر للبحث مستقبلاً
    }
    return new int[]{};
}
// الفكرة: بدلاً من حلقتين متداخلتين O(n²)، نتذكر ما رأيناه بـ HashMap
// ونبحث عن المكمّل بـ O(1) في كل خطوة → O(n) إجمالاً` },

        { type: "code", language: "java", title: "المسألة 2: Valid Parentheses — O(n) باستخدام Stack", content: `/**
 * المشكلة: تحقق أن الأقواس في سلسلة نصية مغلقة بشكل صحيح.
 * المدخل: "({[]})" → true  |  "({)}" → false  |  "(]" → false
 * التعقيد: O(n) وقتاً، O(n) مكاناً
 *
 * لماذا Stack مثالية هنا؟ لأن آخر قوس فُتح يجب أن يُغلق أولاً (LIFO)
 */
public boolean isValid(String s) {
    Deque<Character> stack = new ArrayDeque<>();
    Map<Character, Character> pairs = Map.of(
        ')', '(',
        ']', '[',
        '}', '{'
    );

    for (char ch : s.toCharArray()) {
        if (!pairs.containsKey(ch)) {
            // قوس فتح → أضفه للـ Stack
            stack.push(ch);
        } else {
            // قوس إغلاق → تحقق أن قمة الـ Stack هو المكمّل له
            if (stack.isEmpty() || stack.pop() != pairs.get(ch)) {
                return false;
            }
        }
    }
    return stack.isEmpty();  // إذا بقي شيء في الـ Stack → أقواس غير مغلقة
}` },

        { type: "code", language: "java", title: "المسألة 3: Longest Substring Without Repeating — O(n) بنافذة منزلقة", content: `/**
 * المشكلة: أوجد طول أطول سلسلة فرعية بدون حروف متكررة.
 * المدخل: "abcabcbb" → 3 (abc)  |  "bbbbb" → 1 (b)  |  "pwwkew" → 3 (wke)
 * التعقيد: O(n) وقتاً، O(min(n, m)) مكاناً حيث m عدد الحروف الممكنة
 *
 * تقنية: Sliding Window — نافذة متغيرة الحجم تنزلق على السلسلة
 */
public int lengthOfLongestSubstring(String s) {
    Map<Character, Integer> lastSeen = new HashMap<>();  // {حرف: آخر موقع رأيناه}
    int maxLen = 0;
    int left = 0;   // حد النافذة اليسار

    for (int right = 0; right < s.length(); right++) {
        char ch = s.charAt(right);

        // إذا رأينا هذا الحرف وكان داخل النافذة الحالية
        if (lastSeen.containsKey(ch) && lastSeen.get(ch) >= left) {
            left = lastSeen.get(ch) + 1;  // قلّص النافذة من اليسار
        }

        lastSeen.put(ch, right);                    // سجّل آخر موقع للحرف
        maxLen = Math.max(maxLen, right - left + 1); // حدّث الحد الأقصى
    }
    return maxLen;
}
// المنطق: حافظ على نافذة [left, right] لا تحتوي تكرارات
// إذا دخل حرف مكرر، ازحف left إلى ما بعد آخر ظهور له` },

        { type: "active-recall", questions: [
          { q: "ماذا يعني O(log n) وفي أي خوارزمية يظهر؟", a: "يعني أن الوقت يتضاعف بإضافة كل ضعف للبيانات. يظهر في Binary Search حيث نقسم المصفوفة لنصفين في كل خطوة." },
          { q: "لماذا Binary Search أسرع من Linear Search؟ وما الشرط؟", a: "Binary Search O(log n) مقابل O(n) لـ Linear Search. لكنه يشترط مصفوفة مرتبة مسبقاً." },
          { q: "ما هو HashMap ولماذا البحث فيه O(1)؟", a: "HashMap يستخدم Hash Function لحساب موقع العنصر مباشرة دون البحث السلسلي، لذا الوصول شبه فوري بغض النظر عن حجم البيانات." },
          { q: "متى تختار ArrayList ومتى LinkedList؟", a: "ArrayList عندما تحتاج وصولاً سريعاً بالـ Index. LinkedList عندما تُضيف وتحذف كثيراً من بداية/نهاية القائمة." }
        ]}
      ]
    },
    {
      id: "unit-8",
      stageId: "stage-2",
      unitNumber: 8,
      title: "البرمجة كائنية التوجه OOP",
      description: "الكائنات، الفئات، الركائز الأربع للـ OOP، والـ Abstract Classes والـ Interfaces.",
      content: [
        { type: "h1", content: "الوحدة 8: البرمجة كائنية التوجه (OOP)" },
        { type: "p", content: "OOP هي الطريقة التي تُنظَّم بها معظم التطبيقات الكبيرة. فكرتها المحورية: بدلاً من دوال منفصلة، تُصمّم 'كائنات' تحمل بياناتها وسلوكها معاً — تماماً كما في العالم الحقيقي." },

        { type: "h2", content: "1. الفئات والكائنات — المنطق الأساسي" },
        { type: "p", content: "الـ Class هو القالب (Blueprint). الـ Object هو النسخة المجسّدة في الذاكرة." },
        { type: "code", language: "java", title: "BankAccount.java — مثال شامل", content: `public class BankAccount {
    // الحالة (State) — تصف الكائن
    private final String accountId;
    private String owner;
    private double balance;

    // الدالة البانية (Constructor) — تُنشئ النسخة
    public BankAccount(String accountId, String owner, double initialBalance) {
        if (initialBalance < 0) throw new IllegalArgumentException("الرصيد لا يكون سالباً");
        this.accountId = accountId;
        this.owner = owner;
        this.balance = initialBalance;
    }

    // السلوك (Behavior) — ما يستطيع الكائن فعله
    public void deposit(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("المبلغ يجب أن يكون موجباً");
        this.balance += amount;
        System.out.printf("إيداع: %.2f — الرصيد الجديد: %.2f%n", amount, balance);
    }

    public void withdraw(double amount) {
        if (amount > balance) throw new IllegalStateException("رصيد غير كافٍ");
        this.balance -= amount;
    }

    // toString يُحسّن طباعة الكائن
    @Override
    public String toString() {
        return String.format("[%s] %s — رصيد: %.2f", accountId, owner, balance);
    }

    // Getters — وصول آمن للبيانات الداخلية
    public double getBalance() { return balance; }
    public String getAccountId() { return accountId; }
}

// الاستخدام
BankAccount acc = new BankAccount("ACC-001", "Ahmed", 1000.0);
acc.deposit(500.0);   // إيداع: 500.00 — الرصيد الجديد: 1500.00
acc.withdraw(200.0);
System.out.println(acc); // [ACC-001] Ahmed — رصيد: 1300.00` },

        { type: "h2", content: "2. الركيزة الأولى: التغليف (Encapsulation)" },
        { type: "p", content: "إخفاء التفاصيل الداخلية والتحكم في الوصول. مبدأ: بيانات الكائن ملك له فقط، والعالم الخارجي يتعامل معها فقط عبر الدوال المعلنة." },
        { type: "callout", calloutType: "best-practice", title: "لماذا private وليس public؟", content: [
          { type: "p", content: "إذا جعلت balance عاماً، يمكن لأي كود خارجي كتابة account.balance = -999999 مباشرة. بجعله private، تُجبر كل تعديل على المرور عبر deposit() و withdraw() التي تحتوي على التحقق من الصحة." }
        ]},

        { type: "h2", content: "3. الركيزة الثانية: الوراثة (Inheritance)" },
        { type: "p", content: "يمكن لكلاس (الابن) أن يرث خصائص ودوال كلاس آخر (الأب). هذا يطبق مبدأ DRY ويسمح بالتخصيص." },
        { type: "code", language: "java", title: "نظام الموظفين مع الوراثة", content: `// الكلاس الأب: يحتوي الخصائص المشتركة
public abstract class Employee {
    protected String name;
    protected String id;

    public Employee(String name, String id) {
        this.name = name;
        this.id = id;
    }

    // كل موظف له راتب لكن طريقة الحساب تختلف
    public abstract double calculateSalary();

    public void printInfo() {
        System.out.printf("موظف: %s | الراتب: %.2f%n", name, calculateSalary());
    }
}

// موظف بمرتب ثابت
public class FullTimeEmployee extends Employee {
    private double monthlySalary;

    public FullTimeEmployee(String name, String id, double monthlySalary) {
        super(name, id);  // استدعاء Constructor الأب
        this.monthlySalary = monthlySalary;
    }

    @Override
    public double calculateSalary() { return monthlySalary; }
}

// موظف بالساعة
public class HourlyEmployee extends Employee {
    private double hourlyRate;
    private int hoursWorked;

    public HourlyEmployee(String name, String id, double hourlyRate, int hoursWorked) {
        super(name, id);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    @Override
    public double calculateSalary() { return hourlyRate * hoursWorked; }
}

// الاستخدام
List<Employee> team = new ArrayList<>();
team.add(new FullTimeEmployee("سارة", "E001", 5000));
team.add(new HourlyEmployee("علي", "E002", 50, 160));

// نفس الكود يعمل مع أنواع مختلفة — هذا هو Polymorphism!
for (Employee e : team) {
    e.printInfo();
}` },

        { type: "h2", content: "4. الركيزة الثالثة: تعدد الأشكال (Polymorphism)" },
        { type: "p", content: "نفس الاستدعاء (e.calculateSalary()) يُنتج سلوكاً مختلفاً بحسب نوع الكائن الفعلي. الكود الذي يتعامل مع Employee لا يحتاج أن يعرف إن كان FullTime أو Hourly." },

        { type: "h2", content: "5. الواجهات (Interfaces) مقابل الكلاسات المجردة" },
        { type: "table", headers: ["المعيار", "Abstract Class", "Interface"], rows: [
          ["الإرث", "extends (واحد فقط)", "implements (متعدد)"],
          ["الحقول", "يمكن أن يكون لها حالة (fields)", "ثوابت فقط (constants)"],
          ["الدوال", "يمكن أن تحتوي كوداً", "افتراضياً مجردة (default منذ Java 8)"],
          ["الاستخدام", "عندما تكون 'نوعاً' (is-a)", "عندما تمتلك 'قدرة' (can-do)"],
          ["مثال", "Vehicle → Car", "Flyable → Bird, Airplane"]
        ]},
        { type: "code", language: "java", title: "Interface عملي", content: `// Interface: يعبّر عن قدرة، وليس نوعاً
public interface Printable {
    void print();
    default String getFormat() { return "PDF"; }  // دالة افتراضية
}

public interface Exportable {
    byte[] export(String format);
}

// كلاس يطبق واجهتين في نفس الوقت
public class Report implements Printable, Exportable {
    private String content;

    @Override
    public void print() { System.out.println(content); }

    @Override
    public byte[] export(String format) {
        return content.getBytes();
    }
}` },

        { type: "h2", content: "6. الركيزة الرابعة: التجريد (Abstraction)" },
        { type: "p", content: "إخفاء التعقيد وإظهار ما يهم المستخدم فقط. تعمل مع السيارة دون معرفة كيف يعمل المحرك. تستخدم الـ API دون معرفة تفاصيل التنفيذ." },
        { type: "callout", calloutType: "ai-tip", title: "OOP في مقابلات التوظيف", content: [
          { type: "p", content: "أكثر سؤال شائع: 'ما الفرق بين Abstract Class و Interface؟' والجواب الذكي: Interface للقدرة (can-do)، Abstract Class للنوع (is-a). استخدم Interface عندما تريد الإرث المتعدد." }
        ]},

        { type: "active-recall", questions: [
          { q: "ما الفرق بين Class و Object؟", a: "Class هو القالب (Blueprint) الذي يصف الشكل. Object هو النسخة الحقيقية المنشأة في الذاكرة. يمكن أن تصنع ألف كائن من كلاس واحد." },
          { q: "لماذا نستخدم Encapsulation؟", a: "لحماية حالة الكائن من التعديل المباشر غير الصحيح، وإجبار أي تعديل على المرور عبر دوال تتضمن التحقق من الصحة." },
          { q: "ما الفرق بين Interface و Abstract Class؟", a: "Interface يعبر عن قدرة (can-do) ويسمح بالتطبيق المتعدد. Abstract Class يعبر عن نوع (is-a) ويمكن له حقول وكود." },
          { q: "ما هو Polymorphism وكيف يُبسّط الكود؟", a: "نفس الاستدعاء يُنتج سلوكاً مختلفاً حسب نوع الكائن. يسمح بكتابة كود عام يعمل مع أنواع متعددة دون if/else." }
        ]}
      ]
    },
    {
      id: "unit-9",
      stageId: "stage-2",
      unitNumber: 9,
      title: "معالجة الأخطاء والـ Debugging",
      description: "اكتشاف الأخطاء ومعالجتها احترافياً والـ Debugging المنهجي.",
      content: [
        { type: "h1", content: "الوحدة 9: معالجة الأخطاء والـ Debugging" },
        { type: "p", content: "الفرق بين مبتدئ ومحترف ليس أن المحترف لا يُخطئ، بل أنه يتعامل مع الأخطاء بشكل منهجي ومتحكَّم فيه." },

        { type: "h2", content: "1. أنواع الأخطاء الثلاثة" },
        { type: "table", headers: ["النوع", "متى يظهر؟", "المثال", "طريقة الاكتشاف"], rows: [
          ["Syntax Error (نحوي)", "قبل التشغيل (وقت الترجمة)", "نسيان ; أو }", "المترجم (Compiler) يرفض تشغيل الكود"],
          ["Runtime Error (تشغيلي)", "أثناء التشغيل", "قسمة على صفر، index خارج الحدود", "البرنامج ينهار مع رسالة خطأ"],
          ["Logic Error (منطقي)", "الكود يعمل بنجاح", "حساب مبلغ خاطئ", "الاختبارات والـ Debugging"]
        ]},

        { type: "h2", content: "2. الاستثناءات في Java — التسلسل الهرمي" },
        { type: "ascii", content: `
              Throwable
              /       \\
           Error     Exception
         (JVM errors)   /        \\
                 IOException    RuntimeException
                (Checked)         (Unchecked)
                   |              /    |    \\
              FileNotFound   NullPtr  ArrayIndex  ArithmeticEx
              Exception      Exception  OutOfBounds  Exception
` },
        { type: "p", content: "Checked Exceptions: يجبرك المترجم على التعامل معها (try/catch أو throws). Unchecked Exceptions: لا يُجبرك المترجم، لكنها تُسقط البرنامج إن لم تُعالَج." },

        { type: "h2", content: "3. try-catch-finally بالتفصيل" },
        { type: "code", language: "java", title: "FileReader مع معالجة أخطاء احترافية", content: `import java.io.*;
import java.util.logging.*;

public class FileProcessor {
    private static final Logger logger = Logger.getLogger(FileProcessor.class.getName());

    public static String readFile(String path) throws FileNotFoundException {
        // try-with-resources: يغلق الملف تلقائياً حتى لو حدث خطأ
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\\n");
            }
            return content.toString();

        } catch (FileNotFoundException e) {
            logger.warning("الملف غير موجود: " + path);
            throw e;  // أعد رمي الخطأ ليتعامل معه المستدعي

        } catch (IOException e) {
            logger.severe("خطأ في قراءة الملف: " + e.getMessage());
            throw new RuntimeException("فشل معالجة الملف: " + path, e);
            // الـ cause الأصلية محفوظة (Cause Chaining)
        }
    }
}

// الاستدعاء الصحيح
try {
    String content = FileProcessor.readFile("data.txt");
    processContent(content);
} catch (FileNotFoundException e) {
    showUserError("الملف المطلوب غير موجود. تحقق من المسار.");
} catch (RuntimeException e) {
    showUserError("حدث خطأ في قراءة البيانات. حاول مجدداً.");
    logger.log(Level.SEVERE, "خطأ غير متوقع", e);
}` },

        { type: "h2", content: "4. إنشاء Exceptions مخصصة" },
        { type: "p", content: "بدلاً من رمي Exception عامة، أنشئ exceptions واضحة تصف المشكلة بدقة." },
        { type: "code", language: "java", title: "Custom Exceptions", content: `// استثناء مخصص للأعمال (Business Logic)
public class InsufficientFundsException extends RuntimeException {
    private final double requestedAmount;
    private final double availableBalance;

    public InsufficientFundsException(double requested, double available) {
        super(String.format("طلبت %.2f لكن الرصيد المتاح %.2f فقط", requested, available));
        this.requestedAmount = requested;
        this.availableBalance = available;
    }

    public double getRequestedAmount()  { return requestedAmount; }
    public double getAvailableBalance() { return availableBalance; }
}

// الاستخدام
public void withdraw(double amount) {
    if (amount > this.balance) {
        throw new InsufficientFundsException(amount, this.balance);
    }
    this.balance -= amount;
}

// معالجة ذكية
try {
    account.withdraw(1000);
} catch (InsufficientFundsException e) {
    System.out.printf("عجز: %.2f — أضف %.2f لإتمام العملية%n",
        e.getAvailableBalance(), e.getRequestedAmount() - e.getAvailableBalance());
}` },

        { type: "h2", content: "5. مهارات الـ Debugging المنهجي" },
        { type: "p", content: "قبل أن تضغط Ctrl+Z وتبدأ من جديد، اتبع هذا المسار المنهجي:" },
        { type: "ul", items: [
          [{ type: "p", content: "اقرأ رسالة الخطأ بدقة: Stack Trace يخبرك بالنوع والسطر بالضبط. لا تتخطاها!" }],
          [{ type: "p", content: "افهم ما يحدث مقابل ما تتوقع أن يحدث: وضّح الفجوة بدقة." }],
          [{ type: "p", content: "استخدم الـ Debugger: ضع Breakpoint قبل السطر المشكوك به وراقب قيم المتغيرات." }],
          [{ type: "p", content: "قلّص المشكلة (Isolate): اصنع أبسط مثال ممكن يُعيد المشكلة." }],
          [{ type: "p", content: "ابحث في الـ Logs: الخطأ في السيرفر دائماً في الـ Log قبل أن تراه في الواجهة." }]
        ]},

        { type: "code", language: "java", title: "Logging احترافي بدلاً من System.out.println", content: `import java.util.logging.*;

public class OrderService {
    // Logger واحد لكل كلاس
    private static final Logger log = Logger.getLogger(OrderService.class.getName());

    public Order createOrder(String userId, List<Item> items) {
        log.info(String.format("إنشاء طلب للمستخدم %s | %d عناصر", userId, items.size()));

        try {
            Order order = buildOrder(userId, items);
            log.fine(String.format("تم إنشاء الطلب: %s", order.getId()));
            return order;

        } catch (Exception e) {
            // Level.SEVERE: خطأ حرج يحتاج تدخلاً فورياً
            log.log(Level.SEVERE, "فشل إنشاء الطلب للمستخدم: " + userId, e);
            throw e;
        }
    }
}

// مستويات الـ Logging (من الأهم للأقل):
// SEVERE → WARNING → INFO → CONFIG → FINE → FINER → FINEST` },

        { type: "active-recall", questions: [
          { q: "ما الفرق بين Checked و Unchecked Exception؟", a: "Checked: المترجم يُجبرك على التعامل معها (مثل IOException). Unchecked (RuntimeException): لا إجبار لكنها تُسقط البرنامج (مثل NullPointerException)." },
          { q: "ما فائدة try-with-resources؟", a: "يُغلق الموارد (ملفات، اتصالات قاعدة البيانات) تلقائياً حتى لو حدث استثناء، دون الحاجة لكتلة finally يدوياً." },
          { q: "لماذا نُنشئ Custom Exceptions بدلاً من استخدام Exception العامة؟", a: "Custom Exceptions تُضيف سياقاً (Context) يساعد في الـ Debugging، وتتيح معالجة مختلفة لأنواع مختلفة من الأخطاء." }
        ]}
      ]
    },
    {
      id: "unit-10",
      stageId: "stage-2",
      unitNumber: 10,
      title: "سير عمل المطورين (Git + GitHub)",
      description: "التحكم في الإصدارات، الفروع، Pull Requests، وسير عمل الفريق الاحترافي.",
      content: [
        { type: "h1", content: "الوحدة 10: سير عمل المطورين (Git & GitHub)" },
        { type: "p", content: "Git هو الأداة الأهم التي يستخدمها كل مطور يومياً. ليس مجرد نسخ احتياطي، بل نظام تعاون وتتبع تاريخ كامل يجعل العمل الجماعي ممكناً." },

        { type: "h2", content: "1. المناطق الثلاث في Git" },
        { type: "ascii", content: `
Working Directory → (git add) → Staging Area → (git commit) → Local Repo
(الملفات على جهازك)          (منطقة التجهيز)               (تاريخ local)
                                                                    │
                                                              (git push)
                                                                    │
                                                               Remote Repo
                                                              (GitHub, GitLab)
` },

        { type: "h2", content: "2. أساسيات اليومية" },
        { type: "code", language: "bash", title: "سير العمل اليومي", content: `# ═══ قبل البدء بأي عمل ═══
git pull origin main          # تحديث من الـ Remote
git switch -c feat/user-auth  # إنشاء فرع جديد للميزة

# ═══ أثناء العمل ═══
git status                    # ماذا تغيّر؟
git diff src/auth.ts          # ماذا تغيّر بالتفصيل؟
git add src/auth.ts           # أضف ملفاً محدداً
git add -p                    # اختر تغييرات محددة تفاعلياً

# ═══ بعد إتمام الجزء ═══
git commit -m "feat(auth): add JWT verification middleware"
# صيغة Conventional Commits: type(scope): description

# ═══ رفع ومراجعة ═══
git push origin feat/user-auth
# ثم افتح Pull Request على GitHub` },

        { type: "h2", content: "3. استراتيجيات الفروع (Branching Strategies)" },
        { type: "h3", content: "GitHub Flow — الأبسط والأكثر شيوعاً" },
        { type: "ascii", content: `
main ────────────────────────────────────────────────────►
        │                            ▲
        │ git switch -c feature/X    │ Pull Request + Merge
        ▼                            │
feature/X ──── commit ──── commit ──┘
` },
        { type: "p", content: "GitHub Flow بسيط: main دائماً قابل للنشر، كل ميزة جديدة في فرع منفصل، وكل فرع يُدمج بـ Pull Request بعد المراجعة." },

        { type: "h3", content: "Git Flow — للمشاريع ذات الإصدارات المنظمة" },
        { type: "ascii", content: `
main ──────────────────────────────────(v1.0)──────────────►
       ▲                                 ▲
       │ merge                           │ merge
develop ────────────────────────────────────────────────────►
            ▲                    ▲
            │                    │
feature/A ──┘         feature/B ─┘
` },

        { type: "h2", content: "4. كتابة رسائل Commit احترافية" },
        { type: "p", content: "رسالة الـ Commit ليست لك وحدك — هي سجل تاريخي يقرأه فريقك لأشهر أو سنوات قادمة. معيار Conventional Commits هو الأكثر انتشاراً:" },
        { type: "table", headers: ["النوع", "متى؟", "مثال"], rows: [
          ["feat", "ميزة جديدة", "feat(auth): add Google OAuth"],
          ["fix", "إصلاح bug", "fix(payment): handle zero amount edge case"],
          ["refactor", "تحسين دون تغيير وظيفي", "refactor(users): extract validation to service"],
          ["test", "إضافة اختبارات", "test(orders): add integration tests for checkout"],
          ["docs", "توثيق فقط", "docs(api): update authentication endpoints"],
          ["chore", "صيانة (deps, config)", "chore: upgrade Node to v20"]
        ]},

        { type: "h2", content: "5. Pull Requests وعملية المراجعة" },
        { type: "p", content: "Pull Request (PR) هو طلب رسمي لدمج فرعك بالفرع الرئيسي. يُتيح للفريق مراجعة الكود ومناقشته قبل الدمج." },
        { type: "callout", calloutType: "best-practice", title: "كيف تكتب PR ممتازاً؟", content: [
          { type: "p", content: "العنوان: وصف موجز للميزة أو الإصلاح (مثل: feat: add password reset flow)." },
          { type: "p", content: "الوصف: لماذا هذا التغيير؟ ماذا يفعل؟ كيف اختبرته؟" },
          { type: "p", content: "Screenshots: لأي تغيير في الواجهة، أضف صور قبل/بعد." },
          { type: "p", content: "حجم صغير: PR بأقل من 400 سطر يُراجع بشكل أفضل من PR بـ 2000 سطر." }
        ]},

        { type: "h2", content: "6. التراجع والتصحيح" },
        { type: "code", language: "bash", title: "تراجع آمن عن التغييرات", content: `# ═══ تراجع آمن (لا يحذف تاريخاً) ═══
git revert abc123            # ينشئ commit عكسي (آمن حتى بعد الرفع)

# ═══ تراجع محلي (قبل git push) ═══
git reset --soft HEAD~1      # تراجع عن آخر commit، يبقي التغييرات staged
git reset --mixed HEAD~1     # تراجع، يبقي التغييرات في Working Directory
git reset --hard HEAD~1      # تراجع كامل، يُلغي التغييرات (خطير!)

# ═══ حفظ تغييرات مؤقتة ═══
git stash                    # احفظ التغييرات جانباً
git stash list               # عرض ما تم حفظه
git stash pop                # استرجاع آخر stash (وحذفه من القائمة)
git stash apply stash@{1}    # استرجاع stash محدد بدون حذفه

# ═══ البحث في التاريخ ═══
git log --oneline --graph --all   # تاريخ كامل مرئي
git log -S "calculateTax"         # ابحث عن commits غيّرت دالة معينة
git blame src/orders.ts           # من كتب هذا السطر ومتى؟
git bisect start                  # البحث الثنائي لإيجاد commit أدخل bug` },

        { type: "active-recall", questions: [
          { q: "ما الفرق بين git merge وgit rebase؟", a: "merge يُنشئ commit دمج يحفظ التاريخ كاملاً. rebase يُعيد كتابة التاريخ ليبدو التغيير وكأنه بُني فوق الفرع الهدف مباشرة (تاريخ أنظف)." },
          { q: "ما الفرق بين git reset --soft و --hard؟", a: "soft: يتراجع عن الـ commit ويُبقي التغييرات staged (جاهزة للـ commit مجدداً). hard: يتراجع عن الـ commit ويحذف التغييرات كلياً (خطير!)." },
          { q: "لماذا نستخدم ملف .gitignore؟", a: "لتجاهل الملفات التي لا يجب تتبعها: الملفات المولّدة (node_modules, dist)، البيانات الحساسة (.env)، ملفات المحرر (.vscode)." },
          { q: "ما هو Pull Request وما دوره في سير العمل الجماعي؟", a: "طلب رسمي لدمج فرع بالفرع الرئيسي. يُتيح مراجعة الكود ومناقشته من قبل الفريق وضمان الجودة قبل أي دمج." }
        ]}
      ]
    }
  ]
};
